from collections import defaultdict
from datetime import date
from decimal import Decimal
from io import BytesIO
import os

from django import forms
from django.conf import settings
from django.contrib import admin, messages
from django.db.models import Sum
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.template.response import TemplateResponse
from django.urls import path
from django.utils.html import format_html
from django.utils.safestring import mark_safe
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer

from django.contrib.admin import ModelAdmin

from objednavky.models import OrderItem
from users.models import StravovaciSkupina

from .forms import SpotrebniKosForm
from .models import (
    SkladDashboard,
    Surovina,
    StavSkladu,
    PohybSkladu,
    RecepturaPolozka,
    PrijemSkladu,
    PolozkaPrijmu,
    Inventura,
    PolozkaInventury,
    InventurniDoklad,
    Vydejka,
    PolozkaVydejky,
    NormaSpotrebnihoKose,
    ReportNakladySkladu,
    ToleranceSpotrebnihoKose,
)
from .services import (
    generate_vydejka_from_orders,
    objednavky_rekap_data,
    get_order_items_for_vydejka,
    uzavri_prijem,
    uzavri_vydejku,
    uzavri_inventuru,
    validace_surovin_pro_sk,
    spocitej_stravnikodny_obdobi,
    # ponechávám tvoje existující výpočty:
    
    priprav_naklady_podle_skupin_sk,
    spocitej_podil_masnych_vyrobku,
    spocitej_podil_bio,
    spocitej_volny_cukr,
)


class MesicniNakladyForm(forms.Form):
    rok = forms.IntegerField(label="Rok")
    mesic = forms.IntegerField(min_value=1, max_value=12, label="Měsíc")
    stravovaci_skupina = forms.ModelChoiceField(
        queryset=StravovaciSkupina.objects.all(),
        required=False,
        label="Stravovací skupina",
        help_text="Volitelné – bez výběru se počítají náklady za všechny skupiny.",
    )


@admin.register(ReportNakladySkladu)
class ReportNakladySkladuAdmin(admin.ModelAdmin):
    def get_queryset(self, request):
        return ReportNakladySkladu.objects.none()

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return request.user.is_staff

    def has_delete_permission(self, request, obj=None):
        return False

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path(
                "",
                self.admin_site.admin_view(self.report_view),
                name="sklad_report_naklady",
            ),
        ]
        return custom + urls

    def report_view(self, request):
        today = date.today()
        initial = {"rok": today.year, "mesic": today.month}
        form = MesicniNakladyForm(request.GET or None, initial=initial)

        souhrnne_naklady = None
        naklady_podle_sk = None

        if form.is_valid():
            rok = form.cleaned_data["rok"]
            mesic = form.cleaned_data["mesic"]
            skupina = form.cleaned_data["stravovaci_skupina"]

            souhrnne_naklady = spocitej_naklady_mesic(rok, mesic, skupina)
            naklady_podle_sk = priprav_naklady_podle_skupin_sk(rok, mesic, skupina)

        context = dict(
            self.admin_site.each_context(request),
            title="Report nákladů na suroviny",
            form=form,
            souhrnne_naklady=souhrnne_naklady,
            naklady_podle_sk=naklady_podle_sk,
        )
        return TemplateResponse(request, "admin/sklad/report_naklady.html", context)


@admin.register(NormaSpotrebnihoKose)
class NormaSKAdmin(admin.ModelAdmin):
    list_display = ("stravovaci_skupina", "skupina_sk", "norma_g_mesic")
    list_filter = ("stravovaci_skupina", "skupina_sk")
    search_fields = ("stravovaci_skupina__nazev",)


@admin.register(ToleranceSpotrebnihoKose)
class ToleranceSKAdmin(admin.ModelAdmin):
    list_display = ("stravovaci_skupina", "skupina_sk", "min_pct", "max_pct")
    list_filter = ("stravovaci_skupina", "skupina_sk")
    search_fields = ("stravovaci_skupina__nazev",)


@admin.register(SkladDashboard)
class SkladSpotrebniKosAdmin(ModelAdmin):
    change_list_template = "admin/sklad/mesicni_spotrebni_kos.html"

    def get_queryset(self, request):
        return SkladDashboard.objects.none()

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return request.user.is_staff

    def has_delete_permission(self, request, obj=None):
        return False

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path(
                "mesicni-spotrebni-kos/",
                self.admin_site.admin_view(self.spotrebni_kos_view),
                name="sklad_mesicni_spotrebni_kos",
            ),
        ]
        return custom + urls

    @method_decorator(never_cache)
    def spotrebni_kos_view(self, request):
        form = SpotrebniKosForm(request.GET or None)

        rows = []
        circle_row = None
        maso_stat = None
        bio_stat = None
        volny_cukr_g = None
        data_warnings = validace_surovin_pro_sk()

        if form.is_valid():
            date_from, date_to, label = form.get_period()
            stravovaci_skupina = form.cleaned_data.get("stravovaci_skupina")

            if stravovaci_skupina:
                stravnikodny = spocitej_stravnikodny_obdobi(
                    date_from=date_from,
                    date_to=date_to,
                    stravovaci_skupina=stravovaci_skupina,
                )

                rok = date_from.year
                mesic = date_from.month

                rows = priprav_radky_spotrebi_kos_tabulka(
                    rok=rok,
                    mesic=mesic,
                    stravovaci_skupina=stravovaci_skupina,
                    pocet_stravniku=int(stravnikodny),
                    date_from=date_from,
                    date_to=date_to,
                )

                for r in rows:
                    if r.get("norma_g") or r.get("skutecnost_g"):
                        circle_row = type(
                            "Row",
                            (),
                            {
                                "label": label,
                                "plneni": float(r["skutecnost_pct"]),
                            },
                        )()
                        break

                maso_stat = spocitej_podil_masnych_vyrobku(
                    date_from, date_to, stravovaci_skupina
                )
                bio_stat = spocitej_podil_bio(
                    date_from, date_to, stravovaci_skupina
                )
                volny_cukr_g = spocitej_volny_cukr(
                    date_from, date_to, stravovaci_skupina
                )

        context = dict(
            self.admin_site.each_context(request),
            title="Spotřební koš – nové metodické ukazatele",
            form=form,
            rows=rows,
            circle_row=circle_row,
            maso_stat=maso_stat,
            bio_stat=bio_stat,
            volny_cukr_g=volny_cukr_g,
            data_warnings=data_warnings,
        )
        return TemplateResponse(
            request,
            "admin/sklad/mesicni_spotrebni_kos.html",
            context,
        )


@admin.register(Surovina)
class SurovinaAdmin(admin.ModelAdmin):
    list_display = (
        "nazev",
        "jednotka",
        "skupina_sk",
        "je_masny_vyrobek",
        "je_bio",
        "koeficient_sk",
        "hmotnost_ks_g_display",
        "prumerna_cena_za_jednotku",
    )
    list_filter = ("jednotka", "skupina_sk", "je_masny_vyrobek", "je_bio")
    search_fields = ("nazev",)
    fieldsets = (
        ("Základní údaje", {"fields": ("nazev", "jednotka")}),
        (
            "Spotřební koš",
            {
                "fields": (
                    "skupina_sk",
                    "koeficient_sk",
                    "je_masny_vyrobek",
                    "je_bio",
                    "podil_celozrnne_slozky",
                    "volny_cukr_na_100g",
                ),
            },
        ),
        (
            "Hmotnost a ceny",
            {
                "fields": (
                    "hmotnost_ks_g",
                    "prumerna_cena_za_jednotku",
                ),
            },
        ),
    )
    readonly_fields = ("prumerna_cena_za_jednotku",)

    def hmotnost_ks_g_display(self, obj):
        if obj.jednotka != "ks":
            return "-"
        if obj.hmotnost_ks_g is None:
            return "nenastaveno"
        return f"{obj.hmotnost_ks_g} g"

    hmotnost_ks_g_display.short_description = "g / ks"


@admin.register(StavSkladu)
class StavSkladuAdmin(admin.ModelAdmin):
    list_display = ("surovina", "mnozstvi", "min_mnozstvi")
    readonly_fields = ("surovina", "mnozstvi")

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(PohybSkladu)
class PohybSkladuAdmin(admin.ModelAdmin):
    list_display = ("datum", "surovina", "typ", "mnozstvi", "doklad_link", "poznamka")
    list_filter = ("typ", "datum", "surovina")
    search_fields = ("surovina__nazev", "poznamka")
    date_hierarchy = "datum"

    def doklad_link(self, obj):
        if obj.vydejka_id:
            url = f"/admin/sklad/vydejka/{obj.vydejka_id}/change/"
            return format_html('<a href="{}">Výdejka #{}</a>', url, obj.vydejka_id)
        if obj.prijem_id:
            url = f"/admin/sklad/prijemskladu/{obj.prijem_id}/change/"
            return format_html('<a href="{}">Příjemka #{}</a>', url, obj.prijem_id)
        if obj.inventura_id:
            url = f"/admin/sklad/inventura/{obj.inventura_id}/change/"
            return format_html('<a href="{}">Inventura #{}</a>', url, obj.inventura_id)
        return "-"

    doklad_link.short_description = "Doklad"

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


class LockableInlineMixin:
    def has_add_permission(self, request, obj=None):
        if obj and getattr(obj, "uzavreny", False):
            return False
        return super().has_add_permission(request, obj)

    def has_delete_permission(self, request, obj=None):
        if obj and getattr(obj, "uzavreny", False):
            return False
        return super().has_delete_permission(request, obj)

    def get_readonly_fields(self, request, obj=None):
        if obj and getattr(obj, "uzavreny", False):
            return [f.name for f in self.model._meta.fields]
        return super().get_readonly_fields(request, obj)


class RecepturaPolozkaInline(admin.TabularInline):
    model = RecepturaPolozka
    extra = 1


class PolozkaPrijmuInline(LockableInlineMixin, admin.TabularInline):
    model = PolozkaPrijmu
    extra = 1


class PolozkaInventuryInline(LockableInlineMixin, admin.TabularInline):
    model = PolozkaInventury
    extra = 0
    readonly_fields = ("stav_pred", "rozdil")


class PolozkaInventuryReadOnlyInline(admin.TabularInline):
    model = PolozkaInventury
    extra = 0
    can_delete = False
    readonly_fields = ("surovina", "stav_pred", "fyzicky_stav", "rozdil")
    fields = ("surovina", "stav_pred", "fyzicky_stav", "rozdil")

    def has_add_permission(self, request, obj=None):
        return False

    def has_change_permission(self, request, obj=None):
        return False


class PolozkaVydejkyInline(LockableInlineMixin, admin.TabularInline):
    model = PolozkaVydejky
    extra = 1


@admin.register(PrijemSkladu)
class PrijemSkladuAdmin(admin.ModelAdmin):
    list_display = ("id", "datum", "vytvoril", "uzavreny", "uzavren_at", "uzavrel")
    list_filter = ("uzavreny", "datum")
    inlines = [PolozkaPrijmuInline]
    readonly_fields = ("vytvoril", "uzavren_at", "uzavrel")

    def save_model(self, request, obj, form, change):
        if not obj.pk and not obj.vytvoril:
            obj.vytvoril = request.user
        super().save_model(request, obj, form, change)

    def save_related(self, request, form, formsets, change):
        super().save_related(request, form, formsets, change)
        obj = form.instance

        puvodni = None
        if obj.pk:
            puvodni = PrijemSkladu.objects.filter(pk=obj.pk).values("uzavreny").first()

        if obj.uzavreny and puvodni and not puvodni["uzavreny"]:
            uzavri_prijem(obj, user=request.user)

    def get_readonly_fields(self, request, obj=None):
        ro = list(super().get_readonly_fields(request, obj))
        if obj and obj.uzavreny:
            ro += ["datum", "popis", "uzavreny"]
        return ro

    def has_delete_permission(self, request, obj=None):
        if obj and obj.uzavreny:
            return False
        return super().has_delete_permission(request, obj)


@admin.register(Inventura)
class InventuraAdmin(admin.ModelAdmin):
    list_display = ("id", "datum", "vytvoril", "uzavreny", "uzavren_at", "uzavrel")
    list_filter = ("uzavreny", "datum")
    readonly_fields = ("vytvoril", "uzavren_at", "uzavrel")
    inlines = [PolozkaInventuryInline]

    def save_model(self, request, obj, form, change):
        if not obj.pk and not obj.vytvoril:
            obj.vytvoril = request.user
        super().save_model(request, obj, form, change)

        if not change:
            self._napln_polozky_ze_stavu(obj)

    def _napln_polozky_ze_stavu(self, inventura):
        suroviny = Surovina.objects.select_related("stav").all()
        polozky = []
        for s in suroviny:
            stav = getattr(s, "stav", None)
            stav_mnozstvi = stav.mnozstvi if stav else Decimal("0")
            polozky.append(
                PolozkaInventury(
                    inventura=inventura,
                    surovina=s,
                    stav_pred=stav_mnozstvi,
                    fyzicky_stav=stav_mnozstvi,
                    rozdil=Decimal("0"),
                )
            )
        PolozkaInventury.objects.bulk_create(polozky)

    def save_related(self, request, form, formsets, change):
        super().save_related(request, form, formsets, change)
        obj = form.instance

        puvodni = None
        if obj.pk:
            puvodni = Inventura.objects.filter(pk=obj.pk).values("uzavreny").first()

        if obj.uzavreny and puvodni and not puvodni["uzavreny"]:
            uzavri_inventuru(obj, user=request.user)

    def get_readonly_fields(self, request, obj=None):
        ro = list(super().get_readonly_fields(request, obj))
        if obj and obj.uzavreny:
            ro += ["datum", "popis", "uzavreny"]
        return ro

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(InventurniDoklad)
class InventurniDokladAdmin(admin.ModelAdmin):
    list_display = ("id", "datum", "vytvoril", "pocet_polozek")
    list_filter = ("datum",)
    search_fields = ("id", "vytvoril__username")
    inlines = [PolozkaInventuryReadOnlyInline]

    readonly_fields = ("datum", "popis", "vytvoril", "uzavreny", "uzavren_at", "uzavrel")

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.filter(uzavreny=True)

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    def pocet_polozek(self, obj):
        return obj.polozky.count()

    pocet_polozek.short_description = "Počet položek"


@admin.register(Vydejka)
class VydejkaAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "datum",
        "stravovaci_skupina",
        "typ_stravy",
        "uzavreny",
        "uzavren_at",
        "uzavrel",
    )
    list_filter = ("typ_stravy", "stravovaci_skupina", "datum", "uzavreny")
    search_fields = ("id", "stravovaci_skupina__nazev", "popis")
    readonly_fields = ("vytvoril", "uzavren_at", "uzavrel")
    inlines = [PolozkaVydejkyInline]

    fieldsets = (
        (
            "Základní údaje",
            {
                "fields": ("datum", "stravovaci_skupina", "typ_stravy", "popis"),
            },
        ),
        (
            "Objednané receptury a suroviny",
            {
                "fields": (),
                "description": "",
            },
        ),
        (
            "Stav a audit",
            {
                "fields": ("uzavreny", "vytvoril", "uzavren_at", "uzavrel"),
            },
        ),
    )

    actions = [
        "akce_vygenerovat_z_objednavek",
        "uzavrit_vydejky",
    ]

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path(
                "<int:vydejka_id>/pdf/",
                self.admin_site.admin_view(vydejka_pdf_view),
                name="sklad_vydejka_pdf",
            ),
        ]
        return custom_urls + urls

    def save_model(self, request, obj, form, change):
        if not obj.pk and not obj.vytvoril:
            obj.vytvoril = request.user
        super().save_model(request, obj, form, change)

    def save_related(self, request, form, formsets, change):
        super().save_related(request, form, formsets, change)
        obj = form.instance

        puvodni = None
        if obj.pk:
            puvodni = Vydejka.objects.filter(pk=obj.pk).values("uzavreny").first()

        if obj.uzavreny and puvodni and not puvodni["uzavreny"]:
            uzavri_vydejku(obj, user=request.user)

    @admin.action(description="Uzavřít výdejky a promítnout do skladu")
    def uzavrit_vydejky(self, request, queryset):
        uzavreno = 0
        for vydejka in queryset:
            if uzavri_vydejku(vydejka, user=request.user):
                uzavreno += 1

        self.message_user(
            request,
            f"Uzavřeno a promítnuto do skladu: {uzavreno} výdejek.",
        )

    @admin.action(description="Vygenerovat / přepočítat z objednávek pro zvolené výdejky")
    def akce_vygenerovat_z_objednavek(self, request, queryset):
        pocet = 0
        for vydejka in queryset:
            if vydejka.uzavreny:
                continue
            generate_vydejka_from_orders(
                datum=vydejka.datum,
                stravovaci_skupina=vydejka.stravovaci_skupina,
                typ_stravy=vydejka.typ_stravy,
            )
            pocet += 1

        messages.success(
            request,
            f"Výdejky byly vygenerovány/přepočítány z objednávek ({pocet} ks).",
        )

    def get_fieldsets(self, request, obj=None):
        fieldsets = list(super().get_fieldsets(request, obj))

        if obj and obj.pk:
            title, opts = fieldsets[1]
            opts = dict(opts)

            pdf_button = f"""
                <a href="/admin/sklad/vydejka/{obj.id}/pdf/"
                   class="btn btn-primary"
                   style="margin-bottom: 1em; display: inline-block;">
                    📄 Stáhnout PDF výdejky
                </a>
            """

            opts["description"] = mark_safe(pdf_button + self.objednavky_rekap(obj))
            fieldsets[1] = (title, opts)

        return fieldsets

    def get_readonly_fields(self, request, obj=None):
        ro = list(super().get_readonly_fields(request, obj))
        if obj and obj.uzavreny:
            ro += ["datum", "stravovaci_skupina", "typ_stravy", "popis", "uzavreny"]
        return ro

    def has_delete_permission(self, request, obj=None):
        if obj and obj.uzavreny:
            return False
        return super().has_delete_permission(request, obj)

    def objednavky_rekap(self, obj):
        from django.utils.html import escape

        if not obj or not obj.pk:
            return "Ulož výdejku, aby bylo co spočítat."

        order_items = get_order_items_for_vydejka(obj)

        debug = [
            f"datum: {obj.datum}",
            f"typ_stravy: {obj.typ_stravy}",
            f"stravovaci_skupina: {obj.stravovaci_skupina}",
            f"order_items po filtrech: {order_items.count()}",
        ]

        if not order_items.exists():
            return mark_safe(
                "<br>".join(escape(line) for line in debug)
                + "<br><strong>Pro tento filtr nejsou žádné objednávky.</strong>"
            )

        porce_per_jidlo, jidla = objednavky_rekap_data(obj)

        bloky = []
        for jidlo_id, pocet_porci in porce_per_jidlo.items():
            jidlo = jidla[jidlo_id]

            header_html = (
                "<h4 style='margin-top: 1em;'>"
                f"{jidlo.nazev} "
                "<br/>"
                f"<span style='font-weight: normal; color: #666;'>(porcí: {pocet_porci})</span>"
                "</h4>"
            )

            suroviny_rows = []
            for pol in jidlo.receptura.select_related("surovina").all():
                celk_mnozstvi = pol.mnozstvi_na_porci * pocet_porci
                suroviny_rows.append(
                    "<tr>"
                    f"<td>{pol.surovina.nazev}</td>"
                    f"<td style='text-align:right;'>{pol.mnozstvi_na_porci} {pol.surovina.jednotka}</td>"
                    f"<td style='text-align:right;'>{celk_mnozstvi} {pol.surovina.jednotka}</td>"
                    "</tr>"
                )

            if suroviny_rows:
                table_html = (
                    '<table class="table" style="width: 100%; margin-bottom: 0.5em;">'
                    "<thead>"
                    "<tr>"
                    "<th>Surovina</th>"
                    '<th style="text-align:right;">Na 1 porci</th>'
                    '<th style="text-align:right;">Celkem pro všechny porce</th>'
                    "</tr>"
                    "</thead>"
                    "<tbody>"
                    + "".join(suroviny_rows)
                    + "</tbody>"
                    "</table>"
                )
            else:
                table_html = "<p style='color:#888;'>Jídlo nemá vyplněnou recepturu.</p>"

            bloky.append(header_html + table_html)

        return mark_safe("".join(bloky))

    objednavky_rekap.short_description = "Rekapitulace jídel a surovin"


def vydejka_pdf_view(request, vydejka_id):
    from django.utils.html import escape

    vydejka = get_object_or_404(Vydejka, pk=vydejka_id)

    font_path = os.path.join(settings.BASE_DIR, "static", "fonts", "DejaVuSans.ttf")
    pdfmetrics.registerFont(TTFont("DejaVuSans", font_path))

    styles = getSampleStyleSheet()
    styles["Normal"].fontName = "DejaVuSans"
    styles["Title"].fontName = "DejaVuSans"
    styles["Heading2"].fontName = "DejaVuSans"

    order_items = get_order_items_for_vydejka(vydejka)

    if not order_items.exists():
        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer, pagesize=A4, topMargin=2 * cm, bottomMargin=2 * cm
        )
        elements = []

        sk = vydejka.stravovaci_skupina.kod if vydejka.stravovaci_skupina else "bez skupiny"
        elements.append(
            Paragraph(
                f"Výdejka #{vydejka.id} – {vydejka.datum.strftime('%d.%m.%Y')} ({sk})",
                styles["Title"],
            )
        )
        elements.append(Spacer(1, 0.5 * cm))
        elements.append(
            Paragraph("Pro tento filtr nejsou žádné objednávky.", styles["Normal"])
        )

        doc.build(elements)
        pdf = buffer.getvalue()
        buffer.close()

        response = HttpResponse(pdf, content_type="application/pdf")
        response["Content-Disposition"] = f'attachment; filename="vydejka_{vydejka.id}.pdf"'
        return response

    porce_per_jidlo, jidla = objednavky_rekap_data(vydejka)

    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
    )
    elements = []

    sk = vydejka.stravovaci_skupina.kod if vydejka.stravovaci_skupina else "bez skupiny"
    nadpis = f"Výdejka #{vydejka.id} – {vydejka.datum.strftime('%d.%m.%Y')} ({sk})"
    elements.append(Paragraph(nadpis, styles["Title"]))
    elements.append(Spacer(1, 0.3 * cm))
    elements.append(
        Paragraph(
            f"Typ stravy: {vydejka.get_typ_stravy_display()}",
            styles["Normal"],
        )
    )
    elements.append(Spacer(1, 0.7 * cm))

    for jidlo_id, pocet_porci in porce_per_jidlo.items():
        jidlo = jidla[jidlo_id]

        elements.append(
            Paragraph(
                f"<b>{escape(jidlo.nazev)}</b> – {pocet_porci} ks",
                styles["Heading2"],
            )
        )
        elements.append(Spacer(1, 0.3 * cm))

        receptura = RecepturaPolozka.objects.filter(jidlo=jidlo).select_related("surovina")

        if receptura.exists():
            data = [["Surovina", "Na 1 porci", "Celkem pro všechny porce"]]
            for r in receptura.order_by("surovina__nazev"):
                na_porci = r.mnozstvi_na_porci
                celkem = na_porci * pocet_porci
                data.append(
                    [
                        r.surovina.nazev,
                        f"{na_porci:.3f} {r.surovina.jednotka}",
                        f"{celkem:.3f} {r.surovina.jednotka}",
                    ]
                )

            table = Table(data, colWidths=[7 * cm, 4 * cm, 5 * cm])
            table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                        ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                        ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
                        ("FONTNAME", (0, 0), (-1, 0), "DejaVuSans"),
                        ("FONTNAME", (0, 1), (-1, -1), "DejaVuSans"),
                        ("FONTSIZE", (0, 0), (-1, -1), 9),
                        ("BOTTOMPADDING", (0, 0), (-1, 0), 8),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                    ]
                )
            )
            elements.append(table)
        else:
            elements.append(
                Paragraph(
                    "<i>Jídlo nemá vyplněnou recepturu.</i>",
                    styles["Normal"],
                )
            )

        elements.append(Spacer(1, 0.6 * cm))

    doc.build(elements)
    pdf = buffer.getvalue()
    buffer.close()

    response = HttpResponse(pdf, content_type="application/pdf")
    response["Content-Disposition"] = f'attachment; filename="vydejka_{vydejka.id}.pdf"'
    return response